
-- --------------------------------------------------------

--
-- Table structure for table `sales_report`
--

CREATE TABLE `sales_report` (
  `id` int(11) NOT NULL,
  `id_product` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `total_price` decimal(10,2) DEFAULT NULL,
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `code_product` varchar(255) DEFAULT NULL,
  `name_product` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales_report`
--

INSERT INTO `sales_report` (`id`, `id_product`, `quantity`, `total_price`, `transaction_date`, `code_product`, `name_product`) VALUES
(12, 1, 1, 10.00, '2023-12-21 20:16:46', 'coba1', 'coba1'),
(13, 2, 3, 60.00, '2023-12-21 20:16:46', 'coba2', 'coba2'),
(14, 2, 1, 20.00, '2023-12-27 05:01:20', 'coba2', 'coba2'),
(15, 1, 1, 10.00, '2023-12-27 05:04:09', 'coba1', 'coba1'),
(16, 2, 3, 60.00, '2023-12-27 05:04:09', 'coba2', 'coba2'),
(17, 2, 6, 30000.00, '2023-12-29 04:37:35', 'teh', 'Teh'),
(18, 2, 6, 30000.00, '2023-12-29 05:35:57', 'teh', 'Teh'),
(19, 2, 4, 20000.00, '2023-12-29 07:23:49', 'teh', 'Teh'),
(20, 2, 5, 25000.00, '2023-12-29 07:33:40', 'teh', 'Teh');
